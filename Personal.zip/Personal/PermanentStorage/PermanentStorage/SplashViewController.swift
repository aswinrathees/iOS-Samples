//
//  SecondViewController.swift
//  PermanentStorage
//
//  Created by Aswin R on 22/09/22.
//

import UIKit

class SplashViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
}
