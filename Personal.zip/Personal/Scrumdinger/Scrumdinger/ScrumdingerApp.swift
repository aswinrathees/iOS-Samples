//
//  ScrumdingerApp.swift
//  Scrumdinger
//
//  Created by Aswin R on 29/07/23.
//

import SwiftUI

@main
struct ScrumdingerApp: App {
    var body: some Scene {
        WindowGroup {
            MeetingView()
        }
    }
}
